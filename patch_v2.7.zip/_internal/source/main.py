# -*- coding: utf-8 -*-
import sys
import os
import traceback
import subprocess

class DummyStream:
    def write(self, *args, **kwargs):
        pass

    def flush(self, *args, **kwargs):
        pass

    def isatty(self):
        return False


if getattr(sys, 'stdout', None) is None:
    sys.stdout = DummyStream()
if getattr(sys, 'stderr', None) is None:
    sys.stderr = DummyStream()
if getattr(sys, '__stdout__', None) is None:
    sys.__stdout__ = DummyStream()
if getattr(sys, '__stderr__', None) is None:
    sys.__stderr__ = DummyStream()
if os.name == 'nt':
    original_popen = subprocess.Popen
    _lua_self_executable = os.path.normcase(os.path.abspath(sys.executable))

    def _prepare_bundled_python_child(command, kwargs):
        """Do not pass this PyInstaller process's Qt plugin paths to a fresh child."""
        try:
            if not isinstance(command, (list, tuple)) or len(command) < 2:
                return
            if str(command[1]).casefold() not in ('--run-script', '--run-module'):
                return
            child_executable = os.path.normcase(os.path.abspath(os.fspath(command[0])))
            if child_executable != _lua_self_executable:
                return

            # A frozen parent and child unpack to different _MEI... directories.
            # Inheriting the parent's Qt paths makes the child load plugins/DLLs
            # from the wrong bundle directory and can prevent qwindows.dll loading.
            child_env = kwargs.get('env')
            child_env = os.environ.copy() if child_env is None else child_env.copy()
            for name in (
                'QT_PLUGIN_PATH',
                'QT_QPA_PLATFORM_PLUGIN_PATH',
                'QT_QPA_FONTDIR',
            ):
                child_env.pop(name, None)
            child_env['PYINSTALLER_RESET_ENVIRONMENT'] = '1'
            kwargs['env'] = child_env
        except Exception:
            # Keep subprocess launching functional if an unusual command object
            # or environment mapping is supplied.
            return

    class PatchedPopen(original_popen):
        def __init__(self, *args, **kwargs):
            if 'creationflags' not in kwargs:
                kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
            command = args[0] if args else kwargs.get('args')
            _prepare_bundled_python_child(command, kwargs)
            super().__init__(*args, **kwargs)


    subprocess.Popen = PatchedPopen
if len(sys.argv) >= 3 and sys.argv[1] == '-m' and sys.argv[2] == 'yt_dlp':
    import shutil as _yt_shutil
    import yt_dlp
    _yt_dlp_args = list(sys.argv[3:])
    try:
        _external_index = _yt_dlp_args.index('--external-downloader')
        if _external_index + 1 < len(_yt_dlp_args):
            _external_path = _yt_dlp_args[_external_index + 1]
            if os.path.dirname(_external_path) or os.path.isabs(_external_path):
                _external_available = os.path.isfile(_external_path)
            else:
                _external_available = bool(_yt_shutil.which(_external_path))
            if not _external_available:
                del _yt_dlp_args[_external_index:_external_index + 2]
                try:
                    _external_args_index = _yt_dlp_args.index('--external-downloader-args')
                    del _yt_dlp_args[_external_args_index:_external_args_index + 2]
                except ValueError:
                    pass
    except ValueError:
        pass
    _yt_dlp_args.extend(['--concurrent-fragments', '16'])
    sys.exit(yt_dlp.main(_yt_dlp_args))
os.environ['QT_MEDIA_BACKEND'] = 'ffmpeg'
# Use the original distribution's bundled FFmpeg/ffprobe, not an arbitrary
# executable inherited from the developer machine's PATH.
_bundle_dir = getattr(sys, '_MEIPASS', None)
if not _bundle_dir or not os.path.isdir(_bundle_dir):
    _cand = os.path.join(os.path.dirname(sys.executable), '_internal')
    if os.path.isdir(_cand):
        _bundle_dir = _cand
    else:
        _proj_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        _cand2 = os.path.join(_proj_dir, '_internal')
        if os.path.isdir(_cand2):
            _bundle_dir = _cand2
        else:
            _bundle_dir = os.path.abspath('_internal')

_patches_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'patches')
if os.path.isdir(_patches_dir) and _patches_dir not in sys.path:
    sys.path.insert(0, _patches_dir)
_proj_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if os.path.isdir(_proj_root) and _proj_root not in sys.path:
    sys.path.insert(0, _proj_root)
if _bundle_dir not in sys.path:
    if getattr(sys, 'frozen', False):
        sys.path.insert(0, _bundle_dir)
    else:
        sys.path.append(_bundle_dir)
_ffmpeg_dir = os.path.join(_bundle_dir, 'ffmpeg')
if os.path.isfile(os.path.join(_ffmpeg_dir, 'ffmpeg.exe')):
    os.environ['IMAGEIO_FFMPEG_EXE'] = os.path.join(_ffmpeg_dir, 'ffmpeg.exe')
    os.environ['FFMPEG_BINARY'] = os.path.join(_ffmpeg_dir, 'ffmpeg.exe')
    os.environ['FFPROBE_BINARY'] = os.path.join(_ffmpeg_dir, 'ffprobe.exe')
    os.environ['PATH'] = _ffmpeg_dir + os.pathsep + os.environ.get('PATH', '')

for _cuda_sub in (
    ('nvidia', 'cublas', 'bin'),
    ('nvidia', 'cudnn', 'bin'),
    ('nvidia', 'cuda_runtime', 'bin'),
    ('nvidia', 'cuda_nvrtc', 'bin'),
    ('torch', 'lib'),
    ('ctranslate2',),
):
    _cuda_dir = os.path.join(_bundle_dir, *_cuda_sub)
    if os.path.isdir(_cuda_dir):
        if hasattr(os, 'add_dll_directory'):
            try:
                os.add_dll_directory(_cuda_dir)
            except Exception:
                pass
        os.environ['PATH'] = _cuda_dir + os.pathsep + os.environ.get('PATH', '')
_is_subprocess = len(sys.argv) > 1 and sys.argv[1].startswith('--run-')
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
if not _is_subprocess:
    from app.common.config_manager import get_cpu_threads, get_hf_cache_dir
    __threads = str(get_cpu_threads())
    os.environ['OMP_NUM_THREADS'] = __threads
    os.environ['MKL_NUM_THREADS'] = __threads
    os.environ['OPENBLAS_NUM_THREADS'] = __threads
    os.environ['VECLIB_MAXIMUM_THREADS'] = __threads
    os.environ['NUMEXPR_NUM_THREADS'] = __threads
    os.environ['HF_HOME'] = get_hf_cache_dir()
    os.environ['HF_HUB_DISABLE_SYMLINKS'] = '1'
    os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'
else:
    from app.common.config_manager import get_cpu_threads, get_hf_cache_dir
    os.environ['HF_HOME'] = get_hf_cache_dir()
    os.environ['HF_HUB_DISABLE_SYMLINKS'] = '1'
    os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'

import multiprocessing
import subprocess
from PyQt6.QtCore import (Qt, QSize, QTimer)
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame)
APP_VERSION = '2.6'
LICENSE_POLICY = 'online'
LICENSE_PUBLIC_KEY_PEM = b'-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAuRv0wRJd0q9X19pm0I//1tbejq5CDrkCVwhBl2ZNZmY=\n-----END PUBLIC KEY-----\n'

def get_icon_path():
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, 'icon.ico')
    base_dir = os.path.dirname(os.path.abspath(sys.executable))
    internal_path = os.path.join(base_dir, '_internal', 'icon.ico')
    if os.path.exists(internal_path):
        return internal_path
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.ico')

def get_png_icon_path():
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, 'icon.png')
    base_dir = os.path.dirname(os.path.abspath(sys.executable))
    internal_path = os.path.join(base_dir, '_internal', 'icon.png')
    if os.path.exists(internal_path):
        return internal_path
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png')

def force_native_taskbar_icon(widget, icon_path):
    import ctypes
    if not os.path.exists(icon_path):
        return
    try:
        hwnd = int(widget.winId())
        hicon_small = ctypes.windll.user32.LoadImageW(0, icon_path, 1, 16, 16, 16)
        hicon_big = ctypes.windll.user32.LoadImageW(0, icon_path, 1, 32, 32, 16)
        if hicon_small:
            ctypes.windll.user32.SendMessageW(hwnd, 128, 0, hicon_small)
        if hicon_big:
            ctypes.windll.user32.SendMessageW(hwnd, 128, 1, hicon_big)
        return
    except Exception:
        pass

from app.common import security
try:
    from license_runtime import install_license_override
    install_license_override(security, LICENSE_PUBLIC_KEY_PEM)
except Exception:
    pass

def show_splash_and_check_license(app):
    splash_widget = QWidget()
    splash_widget.setWindowFlags(Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
    splash_widget.setFixedSize(380, 130)
    splash_widget.setObjectName('splash')
    splash_widget.setStyleSheet('#splash { background-color: #1E1E1E; border: 1px solid #333333; }')
    main_layout = QHBoxLayout(splash_widget)
    main_layout.setContentsMargins(30, 20, 30, 20)
    main_layout.setSpacing(20)
    icon_path = get_icon_path()
    png_icon_path = get_png_icon_path()
    if os.path.exists(png_icon_path):
        splash_widget.setWindowIcon(QIcon(png_icon_path))
        lbl_icon = QLabel()
        lbl_icon.setPixmap(QIcon(png_icon_path).pixmap(72, 72))
        lbl_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(lbl_icon)
    if os.path.exists(icon_path):
        force_native_taskbar_icon(splash_widget, icon_path)
    text_layout = QVBoxLayout()
    text_layout.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
    text_layout.setSpacing(4)
    lbl_title = QLabel('luaVietsup')
    lbl_title.setStyleSheet('color: #3498db; font-size: 26px; font-weight: bold; font-family: Arial;')
    lbl_version = QLabel(f'Phiên bản {APP_VERSION} — Đang khởi động...')
    lbl_version.setStyleSheet('color: #E2E8F0; font-size: 13px; font-family: Arial;')
    lbl_wait = QLabel('Vui lòng chờ trong giây lát...')
    lbl_wait.setStyleSheet('color: #94A3B8; font-size: 12px; font-style: italic; font-family: Arial;')
    text_layout.addWidget(lbl_title)
    text_layout.addWidget(lbl_version)
    text_layout.addWidget(lbl_wait)
    main_layout.addLayout(text_layout)
    main_layout.addStretch(1)
    screen = QApplication.primaryScreen().availableGeometry()
    splash_widget.move(screen.width() // 2 - 225, screen.height() // 2 - 75)
    splash_widget.show()
    app.processEvents()
    hwid = security.get_hwid()
    status, msg = security.check_license_online(hwid, APP_VERSION)
    return splash_widget, status, msg

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    if len(sys.argv) > 1:
        if sys.argv[1] == '--run-audio-sep':
            if hasattr(sys, '_MEIPASS'):
                ffmpeg_dir = os.path.join(sys._MEIPASS, 'ffmpeg')
                if os.path.exists(ffmpeg_dir):
                    os.environ['PATH'] = ffmpeg_dir + os.pathsep + os.environ.get('PATH', '')
            try:
                import site
                search_paths = []
                if hasattr(sys, '_MEIPASS'):
                    search_paths.append(sys._MEIPASS)
                if hasattr(site, 'getsitepackages'):
                    search_paths.extend(site.getsitepackages())
                for p in search_paths:
                    for sub in ('nvidia/cublas/bin', 'nvidia/cudnn/bin', 'nvidia/cuda_runtime/bin', 'torch/lib'):
                        dll_path = os.path.join(p, sub.replace('/', os.sep))
                        if os.path.exists(dll_path):
                            if hasattr(os, 'add_dll_directory'):
                                os.add_dll_directory(dll_path)
                            os.environ['PATH'] = dll_path + os.pathsep + os.environ.get('PATH', '')
            except Exception:
                pass
            from audio_separator.separator import Separator
            input_file = sys.argv[2]
            out_dir = sys.argv[3]
            model_name = sys.argv[4]
            use_cuda = sys.argv[5].lower() == 'true'
            segment_size = int(sys.argv[6])
            overlap = int(sys.argv[7])
            try:
                sys.stdout.reconfigure(encoding='utf-8')
                sys.stderr.reconfigure(encoding='utf-8')
            except Exception:
                pass
            from app.common.config_manager import get_audio_sep_cache_dir
            cache_dir = get_audio_sep_cache_dir()
            if not use_cuda:
                os.environ['CUDA_VISIBLE_DEVICES'] = ''
            is_roformer_model = 'roformer' in model_name.lower()
            mdx_overlap_map = {2: 0.1, 4: 0.25, 8: 0.5}
            mdx_overlap = mdx_overlap_map.get(overlap, 0.25)
            if is_roformer_model:
                roformer_overlap_map = {2: 0.25, 4: 0.5, 8: 1.0}
                mdxc_overlap = roformer_overlap_map.get(overlap, 0.5)
            else:
                mdxc_overlap = overlap
            separator = Separator(output_dir=out_dir, output_format='WAV', model_file_dir=cache_dir, mdxc_params={'segment_size': segment_size, 'override_model_segment_size': False, 'batch_size': 1, 'overlap': mdxc_overlap, 'pitch_shift': 0}, mdx_params={'segment_size': segment_size, 'overlap': mdx_overlap, 'batch_size': 1, 'hop_length': 1024, 'enable_denoise': False})
            try:
                separator.load_model(model_filename=model_name)
                output_files = separator.separate(input_file)
                for file in output_files:
                    old_path = os.path.join(out_dir, file)
                    if 'Instrumental' in file:
                        new_path = os.path.join(out_dir, 'no_vocals.wav')
                    elif 'Vocals' in file:
                        new_path = os.path.join(out_dir, 'vocals.wav')
                    else:
                        continue
                    if os.path.exists(new_path):
                        os.remove(new_path)
                    os.rename(old_path, new_path)
            except Exception as e:
                traceback.print_exc(file=sys.stderr)
                sys.exit(1)
            sys.exit(0)
        elif sys.argv[1] == '--run-script' and len(sys.argv) > 2:
            script_path = sys.argv[2]
            sys.argv = [sys.argv[0]] + sys.argv[3:]
            import importlib.util
            spec = importlib.util.spec_from_file_location('__main__', script_path)
            module = importlib.util.module_from_spec(spec)
            import sys
            sys.modules['__main__'] = module
            spec.loader.exec_module(module)
            sys.exit(0)
        elif sys.argv[1] == '--run-module' and len(sys.argv) > 2:
            import runpy
            module_name = sys.argv[2]
            sys.argv = [sys.argv[0]] + sys.argv[3:]
            runpy.run_module(module_name, run_name='__main__', alter_sys=True)
            sys.exit(0)
        elif sys.argv[1] == '-c' and len(sys.argv) > 2:
            code = sys.argv[2]
            sys.argv = [sys.argv[0]] + sys.argv[3:]
            exec(code)
            sys.exit(0)
    if os.name == 'nt':
        import ctypes
        myappid = 'luaVietsup.Pro.App.' + APP_VERSION
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception:
            pass
    from qfluentwidgets import (setTheme, Theme, setThemeColor, qconfig)
    os.environ['QT_STYLE_OVERRIDE'] = 'Fusion'
    import qfluentwidgets
    if hasattr(qfluentwidgets, 'isDarkTheme'):
        qfluentwidgets.isDarkTheme = lambda: True
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    qconfig.set(qconfig.themeMode, Theme.DARK, save=False)
    setTheme(Theme.DARK)
    from PyQt6.QtGui import QColor
    fixed_color = QColor('#3498db')
    qconfig.set(qconfig.themeColor, fixed_color, save=False)
    setThemeColor(fixed_color)
    from PyQt6.QtGui import QPalette
    dark_palette = QPalette()
    dark_palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Base, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.ColorRole.AlternateBase, QColor(30, 30, 30))
    dark_palette.setColor(QPalette.ColorRole.ToolTipBase, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
    dark_palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.black)
    app.setPalette(dark_palette)
    setTheme(Theme.DARK)
    try:
        from app.common.font_manager import load_custom_fonts
        load_custom_fonts()
    except Exception as e:
        print('Lỗi nạp font:', e)
    png_icon_path = get_png_icon_path()
    if os.path.exists(png_icon_path):
        app.setWindowIcon(QIcon(png_icon_path))
    splash, license_status, license_msg = show_splash_and_check_license(app)
    import app.core.security as core_sec
    core_sec.CURRENT_LICENSE_STATUS = license_status
    from sir_recovered_runtime import install as install_recovered_fixes
    from sir_recovered_runtime import hide_contact_information, add_hwid_copy_controls, rebrand_visible_sirvietsub, setup_chatgpt_settings_ui, setup_chatgpt_home_ui, install_model_download_fixes, setup_update_settings_ui
    install_recovered_fixes()
    from qfluentwidgets import (FluentWindow, NavigationItemPosition, SplashScreen)
    from qfluentwidgets import FluentIcon as FIF
    from app.views.home_interface import HomeInterface
    from app.views.library_interface import LibraryInterface
    from app.views.highlight_interface import HighlightInterface
    from app.views.setting_interface import SettingInterface
    install_model_download_fixes()
    from app.views.report_interface import ReportInterface
    from app.views.douyin_interface import DouyinInterface
    from app.views.tts_interface import TTSInterface
    from app.views.video_splitter_interface import VideoSplitterInterface
    from app.views.dictionary_interface import DictionaryInterface
    class MainWindow(FluentWindow):
        def __init__(self, lic_status, lic_msg):
            super().__init__()
            self.license_status = lic_status
            self.license_msg = lic_msg
            self.initWindow()
            self.homeInterface = HomeInterface(self)
            self.homeInterface.license_status = lic_status
            setup_chatgpt_home_ui(self.homeInterface)
            self.libraryInterface = LibraryInterface(self)
            self.highlightInterface = HighlightInterface(self)
            self.settingInterface = SettingInterface(self)
            hide_contact_information(self.settingInterface)
            add_hwid_copy_controls(self.settingInterface)
            rebrand_visible_sirvietsub(self.settingInterface)
            setup_chatgpt_settings_ui(self.settingInterface)
            setup_update_settings_ui(self.settingInterface, APP_VERSION)
            try:
                from cloud_assets_runtime import setup_cloud_assets_ui
                setup_cloud_assets_ui(self.settingInterface)
            except Exception:
                pass
            self.settingInterface.setLicenseInfo(lic_status, lic_msg)
            self.reportInterface = ReportInterface(self)
            self.douyinInterface = DouyinInterface(self)
            self.ttsInterface = TTSInterface(self)
            self.splitterInterface = VideoSplitterInterface(self)
            self.dictInterface = DictionaryInterface(self)
            for interface in (
                self.homeInterface, self.libraryInterface, self.highlightInterface,
                self.settingInterface, self.reportInterface, self.douyinInterface,
                self.ttsInterface, self.splitterInterface, self.dictInterface
            ):
                try:
                    if hasattr(interface, 'view') and interface.view:
                        interface.view.setStyleSheet("background-color: #202020; border: none;")
                    interface.setStyleSheet("background-color: #202020; border: none;")
                except Exception:
                    pass
            self.initNavigation()
            self.splashScreen.finish()
            QTimer.singleShot(1500, self.show_license_notification)
            QTimer.singleShot(2000, self.check_update)

        def show_license_notification(self):
            from qfluentwidgets import InfoBar, InfoBarPosition
            lic_status = self.license_status
            lic_msg = self.license_msg
            if lic_status == 'premium':
                InfoBar.success(title='PREMIUM', content=lic_msg, parent=self, position=InfoBarPosition.TOP, duration=5000)
                return
            if lic_status == 'paid':
                InfoBar.success(title='VIP', content=lic_msg, parent=self, position=InfoBarPosition.TOP, duration=5000)
                return
            if lic_status == 'trial':
                InfoBar.warning(title='Dùng thử', content=lic_msg, parent=self, position=InfoBarPosition.TOP, duration=7000)
                return
            InfoBar.error(title='Hết hạn', content='liên hệ qua telegram để kích hoạt bản quyền: https://t.me/oxhexs', parent=self, position=InfoBarPosition.TOP, duration=10000)

        def check_update(self):
            from sir_recovered_runtime import handle_check_update
            handle_check_update(self, APP_VERSION)

        def initNavigation(self):
            self.addSubInterface(self.homeInterface, FIF.HOME, 'Trang chủ')
            self.addSubInterface(self.libraryInterface, FIF.VIDEO, 'Quản lý Video')
            self.addSubInterface(self.highlightInterface, FIF.FOLDER, 'Cắt Highlight')
            self.addSubInterface(self.splitterInterface, FIF.CUT, 'Chia tập cho Video')
            self.addSubInterface(self.douyinInterface, FIF.DOWNLOAD, 'Tải Douyin/TikTok/Bili')
            self.addSubInterface(self.ttsInterface, FIF.MICROPHONE, 'Text to Speech')
            self.addSubInterface(self.dictInterface, FIF.BOOK_SHELF, 'Từ điển Phát âm')
            self.addSubInterface(self.reportInterface, FIF.FEEDBACK, 'Báo lỗi / Hỗ trợ', NavigationItemPosition.BOTTOM)
            self.addSubInterface(self.settingInterface, FIF.SETTING, 'Cài đặt', NavigationItemPosition.BOTTOM)

            def _open_telegram_nav():
                import webbrowser
                from PyQt6.QtCore import QUrl
                from PyQt6.QtGui import QDesktopServices
                try:
                    if not QDesktopServices.openUrl(QUrl("https://t.me/oxhexs")):
                        webbrowser.open("https://t.me/oxhexs")
                except Exception:
                    webbrowser.open("https://t.me/oxhexs")

            try:
                self.navigationInterface.addItem(
                    routeKey='telegram_activate',
                    icon=FIF.CHAT,
                    text='Kích hoạt bản quyền',
                    onClick=_open_telegram_nav,
                    selectable=False,
                    position=NavigationItemPosition.BOTTOM
                )
            except Exception:
                pass

            from PyQt6.QtGui import QFontMetrics
            fm = QFontMetrics(self.font())
            menu_items = ['Trang chủ', 'Quản lý Video', 'Cắt Highlight', 'Chia tập cho Video', 'Tải Douyin/TikTok/Bili', 'Text to Speech', 'Từ điển Phát âm', 'Cài đặt', 'Báo lỗi / Hỗ trợ']
            max_text_width = max((fm.horizontalAdvance(text) for text in menu_items))
            optimal_width = max_text_width + 80
            try:
                self.navigationInterface.setExpandWidth(optimal_width)
            except Exception:
                pass
            if hasattr(self.navigationInterface, 'setReturnButtonVisible'):
                self.navigationInterface.setReturnButtonVisible(False)
                return
            if hasattr(self.navigationInterface.panel, 'setReturnButtonVisible'):
                self.navigationInterface.panel.setReturnButtonVisible(False)

        def initWindow(self):
            self.resize(1200, 700)
            icon_path = get_icon_path()
            png_icon_path = get_png_icon_path()
            if os.path.exists(png_icon_path):
                self.setWindowIcon(QIcon(png_icon_path))
            if os.path.exists(icon_path):
                force_native_taskbar_icon(self, icon_path)
            self.setWindowTitle(f'luaVietsup v{APP_VERSION}')
            desktop = QApplication.primaryScreen().availableGeometry()
            w, h = desktop.width(), desktop.height()
            self.move(w // 2 - self.width() // 2, h // 2 - self.height() // 2)

            # Vo hieu hoa acrylic/mica blur nhin xuyen desktop; bat buoc nen den dac 100%
            if hasattr(self, 'setMicaEffectEnabled'):
                self.setMicaEffectEnabled(False)
            if hasattr(self, 'windowEffect'):
                try:
                    self.windowEffect.removeBackgroundEffect(self.winId())
                    self.windowEffect.disableBlurBehindWindow(self.winId())
                except Exception:
                    pass
            self.setCustomBackgroundColor(QColor(32, 32, 32), QColor(32, 32, 32))
            self.setBackgroundColor(QColor(32, 32, 32))
            self.stackedWidget.setStyleSheet("StackedWidget { background-color: #202020; border: none; }")
            self.setStyleSheet("""
                MainWindow, FluentWindow, FluentWindowBase {
                    background-color: #202020;
                }
                StackedWidget {
                    background-color: #202020;
                    border: none;
                }
                NavigationInterface, NavigationPanel {
                    background-color: #1A1A1A;
                }
            """)

            self.splashScreen = SplashScreen(self.windowIcon(), self)
            self.splashScreen.setIconSize(QSize(102, 102))
            self.splashScreen.raise_()

        def paintEvent(self, e):
            from PyQt6.QtGui import QPainter
            painter = QPainter(self)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(32, 32, 32))
            painter.drawRect(self.rect())
            super().paintEvent(e)

        def showEvent(self, e):
            super().showEvent(e)
            if hasattr(self, 'windowEffect'):
                try:
                    self.windowEffect.removeBackgroundEffect(self.winId())
                    self.windowEffect.disableBlurBehindWindow(self.winId())
                except Exception:
                    pass

        def closeEvent(self, event):
            is_running = False
            if hasattr(self, 'homeInterface') and hasattr(self.homeInterface, 'btn_cancel') and self.homeInterface.btn_cancel.isEnabled():
                is_running = True
            from qfluentwidgets import MessageBox
            title = 'Xác nhận thoát'
            if is_running:
                content = 'Hệ thống đang xử lý công việc. Bạn có chắc chắn muốn hủy bỏ toàn bộ và thoát ứng dụng không?'
            else:
                content = 'Bạn có chắc chắn muốn thoát ứng dụng không?'
            w = MessageBox(title, content, self.window())
            w.yesButton.setText('Có')
            w.cancelButton.setText('Hong')
            if not w.exec():
                event.ignore()
                return
            if is_running:
                self.homeInterface._onCancelClicked()
                import time
                time.sleep(0.5)
            if hasattr(self.libraryInterface, 'current_ai_worker') and self.libraryInterface.current_ai_worker:
                self.libraryInterface.current_ai_worker.cancel()
            if hasattr(self.highlightInterface, 'worker') and self.highlightInterface.worker:
                self.highlightInterface.worker.cancel()
            if hasattr(self, 'douyinInterface') and hasattr(self.douyinInterface, 'image_worker') and self.douyinInterface.image_worker:
                self.douyinInterface.image_worker.stop()
                self.douyinInterface.image_worker.quit()
                self.douyinInterface.image_worker.wait(1000)
            if hasattr(self, 'ttsInterface') and hasattr(self.ttsInterface, 'worker') and self.ttsInterface.worker:
                self.ttsInterface.worker.cancel()
                self.ttsInterface.worker.quit()
                self.ttsInterface.worker.wait(1000)
            super().closeEvent(event)


    w = MainWindow(license_status, license_msg)
    w.show()
    splash.close()
    app.exec()
