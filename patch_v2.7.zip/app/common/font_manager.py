import os
import sys
import struct
from PyQt6.QtGui import QFontDatabase

_custom_fonts = {}
_font_families = {}


def _extract_ttf_family(font_path):
    try:
        with open(font_path, 'rb') as f:
            data = f.read()
        if data[:4] not in (b'OTTO', b'\x00\x01\x00\x00', b'true'):
            return None
        num_tables, = struct.unpack('>H', data[4:6])
        name_offset = None
        for i in range(num_tables):
            if data[12+i*16:16+i*16] == b'name':
                name_offset, = struct.unpack('>I', data[12+i*16+8:12+i*16+12])
                break
        if not name_offset:
            return None
        count, string_offset = struct.unpack('>HH', data[name_offset+2:name_offset+6])
        storage = name_offset + string_offset
        names = {}
        for i in range(count):
            rec = data[name_offset+6+i*12:name_offset+6+(i+1)*12]
            plat, enc, lang, name_id, length, offset = struct.unpack('>HHHHHH', rec)
            val = data[storage+offset:storage+offset+length]
            try:
                s = val.decode('utf-16-be') if plat in (0, 3) else val.decode('latin1', 'ignore')
                names.setdefault(name_id, []).append(s)
            except Exception:
                pass
        id1 = names.get(1, [None])[0]
        id4 = names.get(4, [None])[0]
        return id1 or id4
    except Exception:
        return None


def load_custom_fonts():
    candidate_dirs = []

    # 1. Root relative to __file__
    base_file = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    candidate_dirs.append(os.path.join(base_file, 'assets', 'fonts'))
    candidate_dirs.append(os.path.join(base_file, '_internal', 'assets', 'fonts'))

    # 2. Executable dir
    if getattr(sys, 'frozen', False) or hasattr(sys, 'executable'):
        base_exe = os.path.dirname(os.path.abspath(sys.executable))
        candidate_dirs.append(os.path.join(base_exe, 'assets', 'fonts'))
        candidate_dirs.append(os.path.join(base_exe, '_internal', 'assets', 'fonts'))

    # 3. PyInstaller bundle
    if hasattr(sys, '_MEIPASS'):
        candidate_dirs.append(os.path.join(sys._MEIPASS, 'assets', 'fonts'))
        candidate_dirs.append(os.path.join(sys._MEIPASS, '_internal', 'assets', 'fonts'))

    for fonts_dir in candidate_dirs:
        if not os.path.isdir(fonts_dir):
            continue
        try:
            for f in os.listdir(fonts_dir):
                if f.lower().endswith(('.ttf', '.otf', '.woff', '.woff2')):
                    display_name = os.path.splitext(f)[0]
                    if display_name in _custom_fonts:
                        continue
                    full_path = os.path.join(fonts_dir, f)
                    font_id = QFontDatabase.addApplicationFont(full_path)
                    _custom_fonts[display_name] = full_path
                    libass_family = _extract_ttf_family(full_path)
                    if libass_family:
                        _font_families[display_name] = libass_family
                    elif font_id != -1:
                        families = QFontDatabase.applicationFontFamilies(font_id)
                        if families:
                            _font_families[display_name] = families[0]
                        else:
                            _font_families[display_name] = display_name
                    else:
                        _font_families[display_name] = display_name
        except Exception:
            pass


def get_font_file(display_name):
    """Lấy đường dẫn tuyệt đối của font file dựa trên tên file."""
    if not _custom_fonts:
        load_custom_fonts()
    return _custom_fonts.get(display_name, None)


def get_font_family(display_name):
    """Lấy họ font (Font Family) thật sự cho libass, dựa trên tên file."""
    if not _font_families:
        load_custom_fonts()
    return _font_families.get(display_name, display_name)


def get_custom_font_families():
    """Lấy danh sách TÊN FILE (không đuôi) để hiển thị lên giao diện 100%."""
    if not _custom_fonts:
        load_custom_fonts()
    return list(_custom_fonts.keys())
