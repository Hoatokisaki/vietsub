import os
import sys
from PyQt6.QtGui import QFontDatabase

_custom_fonts = {}
_font_families = {}


def load_custom_fonts():
    candidate_dirs = []

    # 1. Root relative to __file__
    base_file = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    candidate_dirs.append(os.path.join(base_file, 'assets', 'fonts'))
    candidate_dirs.append(os.path.join(base_file, '_internal', 'assets', 'fonts'))

    # 2. Executable dir
    if getattr(sys, 'frozen', False) or hasattr(sys, 'executable'):
        base_exe = os.path.dirname(os.path.abspath(sys.executable))
        candidate_dirs.append(os.path.join(base_exe, 'assets', 'fonts'))
        candidate_dirs.append(os.path.join(base_exe, '_internal', 'assets', 'fonts'))

    # 3. PyInstaller bundle
    if hasattr(sys, '_MEIPASS'):
        candidate_dirs.append(os.path.join(sys._MEIPASS, 'assets', 'fonts'))
        candidate_dirs.append(os.path.join(sys._MEIPASS, '_internal', 'assets', 'fonts'))

    for fonts_dir in candidate_dirs:
        if not os.path.isdir(fonts_dir):
            continue
        try:
            for f in os.listdir(fonts_dir):
                if f.lower().endswith(('.ttf', '.otf', '.woff', '.woff2')):
                    display_name = os.path.splitext(f)[0]
                    if display_name in _custom_fonts:
                        continue
                    full_path = os.path.join(fonts_dir, f)
                    font_id = QFontDatabase.addApplicationFont(full_path)
                    _custom_fonts[display_name] = full_path
                    if font_id != -1:
                        families = QFontDatabase.applicationFontFamilies(font_id)
                        if families:
                            _font_families[display_name] = families[0]
                        else:
                            _font_families[display_name] = display_name
                    else:
                        _font_families[display_name] = display_name
        except Exception:
            pass


def get_font_file(display_name):
    """Lấy đường dẫn tuyệt đối của font file dựa trên tên file."""
    if not _custom_fonts:
        load_custom_fonts()
    return _custom_fonts.get(display_name, None)


def get_font_family(display_name):
    """Lấy họ font (Font Family) thật sự cho libass, dựa trên tên file."""
    if not _font_families:
        load_custom_fonts()
    return _font_families.get(display_name, display_name)


def get_custom_font_families():
    """Lấy danh sách TÊN FILE (không đuôi) để hiển thị lên giao diện 100%."""
    if not _custom_fonts:
        load_custom_fonts()
    return list(_custom_fonts.keys())
